﻿using ProductMicroservice.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/*
https://www.c-sharpcorner.com/article/microservice-using-asp-net-core/
Good Website
 */

namespace ProductMicroservice.Model.Repository
{
    public interface IProductRepository
    {
        Task<IEnumerable<ProductDto>> GetAll();
        Task<ProductDto> GetById(int productId);
        Task<ProductDto> Add(ProductDto productDto);
        Task<ProductDto> Update(ProductDto productDto);
        Task<bool> Delete(int productId);
    }
}
