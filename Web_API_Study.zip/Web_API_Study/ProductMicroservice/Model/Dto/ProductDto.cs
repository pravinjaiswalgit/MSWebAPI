﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/*
https://www.c-sharpcorner.com/article/microservice-using-asp-net-core/
Good Website
 */

namespace ProductMicroservice.Model.Dto
{
    public class ProductDto
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public int Price { get; set; }
        public int CategoryId { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public int Objectversion { get; set; }
    }
}
