﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/*
https://www.c-sharpcorner.com/article/microservice-using-asp-net-core/
Good Website
 */

namespace ProductMicroservice.Model.Dto
{
    public class ResponseDto
    {
        public bool IsSuccess { get; set; } = true;
        public object Result { get; set; }
        public string DisplayMessage { get; set; }
        public List<String> ErrorMessages { get; set; }
    }
}
