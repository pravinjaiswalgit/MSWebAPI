﻿using Microsoft.EntityFrameworkCore;
using ProductMicroservice.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductMicroservice.DBContexts
{
    public class ProductContext : DbContext
    {
        public ProductContext(DbContextOptions<ProductContext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category
                {
                    CategoryId = 1,
                    Name = "Electronics",
                    Description = "Electronic Items",
                    CreatedDate = DateTime.Now,
                    CreatedBy = "Master Data Input",
                    UpdatedDate = DateTime.Now,
                    UpdatedBy = "Master Data Input",
                    Objectversion = 1,
                },
                new Category
                {
                    CategoryId = 2,
                    Name = "Clothes",
                    Description = "Dresses",
                    CreatedDate = DateTime.Now,
                    CreatedBy = "Master Data Input",
                    UpdatedDate = DateTime.Now,
                    UpdatedBy = "Master Data Input",
                    Objectversion = 1,
                },
                new Category
                {
                    CategoryId = 3,
                    Name = "Grocery",
                    Description = "Grocery Items",
                    CreatedDate = DateTime.Now,
                    CreatedBy = "Master Data Input",
                    UpdatedDate = DateTime.Now,
                    UpdatedBy = "Master Data Input",
                    Objectversion = 1,

                }
            );

            modelBuilder.Entity<Product>().HasData(
                    new Product
                    {
                        ProductId = 1,
                        Name = "Electronics-1",
                        Description = "Electronic Items",
                        ImageUrl = "",
                        Price = 10,
                        CategoryId = 1,
                        CreatedDate = DateTime.Now,
                        CreatedBy = "Master Data Input",
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "Master Data Input",
                        Objectversion = 1,
                    },
                    new Product
                    {
                        ProductId = 2,
                        Name = "Electronics-2",
                        Description = "Electronic Items",
                        ImageUrl = "",
                        Price = 10,
                        CategoryId = 1,
                        CreatedDate = DateTime.Now,
                        CreatedBy = "Master Data Input",
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "Master Data Input",
                        Objectversion = 1,
                    },
                    new Product
                    {
                        ProductId = 3,
                        Name = "Electronics-3",
                        Description = "Electronic Items",
                        ImageUrl = "",
                        Price = 10,
                        CategoryId = 1,
                        CreatedDate = DateTime.Now,
                        CreatedBy = "Master Data Input",
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "Master Data Input",
                        Objectversion = 1,

                    },
                    new Product
                    {
                        ProductId = 4,
                        Name = "Electronics-4",
                        Description = "Electronic Items",
                        ImageUrl = "",
                        Price = 10,
                        CategoryId = 1,
                        CreatedDate = DateTime.Now,
                        CreatedBy = "Master Data Input",
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "Master Data Input",
                        Objectversion = 1,

                    },
                    new Product
                    {
                        ProductId = 5,
                        Name = "Electronics-5",
                        Description = "Electronic Items",
                        ImageUrl = "",
                        Price = 10,
                        CategoryId = 1,
                        CreatedDate = DateTime.Now,
                        CreatedBy = "Master Data Input",
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "Master Data Input",
                        Objectversion = 1,

                    }
                );
        }

    }
}



