﻿//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace ProductMicroservice.Controllers
//{
//    [Route("api/products")]
//    [ApiController]
//    public class ProductController : ControllerBase
//    {
//        //public IActionResult Index()
//        //{
//        //    return View();
//        //}
//    }
//}


using ProductMicroservice.Model.Dto;
using ProductMicroservice.Model.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductMicroservice.Controllers
{ 
    // [Route("api/[controller]")]
    [Route("api/products")]
    [ApiController]
    public class ProductAPIController : ControllerBase
    {
        //protected ResponseDto _response;
        private IProductRepository _productRespository;

        public ProductAPIController(IProductRepository productRepository)
        {
            _productRespository = productRepository;
            this._response = new ResponseDto();
        }
        [HttpGet]
        public async Task<object> Get()
        {
            try
            {
                IEnumerable<ProductDto> productDtos = await _productRespository.GetProducts();
                _response.Result = productDtos;
                // _response.IsSuccess = true;
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.ErrorMessages = new List<string>() { ex.ToString() };
            }
            return _response;
        }


        [HttpGet]
        [Route("{id}")]
        public async Task<object> Get(int id)
        {
            try
            {
                ProductDto productDto = await _productRespository.GetProductById(id);
                _response.Result = productDto;
                // _response.IsSuccess = true;
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.ErrorMessages = new List<string>() { ex.ToString() };
            }
            return _response;
        }

        [HttpPost]
        public async Task<object> Post(ProductDto productDto)
        {
            try
            {
                ProductDto model = await _productRespository.CreateUpdateProdcut(productDto);
                _response.Result = model;
                // _response.IsSuccess = true;
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.ErrorMessages = new List<string>() { ex.ToString() };
            }
            return _response;
        }
        [HttpPut]
        public async Task<object> Put([FromBody] ProductDto productDto)
        {
            try
            {
                ProductDto model = await _productRespository.CreateUpdateProdcut(productDto);
                _response.Result = model;
                // _response.IsSuccess = true;
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.ErrorMessages = new List<string>() { ex.ToString() };
            }
            return _response;
        }
        [HttpDelete]
        [Route("{id}")]
        public async Task<object> Delete(int id)
        {
            try
            {
                bool isSuccess = await _productRespository.DeleteProduct(id);
                _response.Result = isSuccess;
                // _response.IsSuccess = true;
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.ErrorMessages = new List<string>() { ex.ToString() };
            }
            return _response;
        }
    }
}
