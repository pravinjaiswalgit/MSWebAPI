﻿Sai@1234
ak53574



avl-dev.database.windows.net
username: avl-admin
password: ,R7#JwHD.w5gs!ZS
103.208.71.86


Server name: 
avl-dev.database.windows.net
username: avl-admin
password: ,R7#JwHD.w5gs!ZS

Server name: 
avl-sql.database.windows.net 
username: avl-readonly 
password: ,R7#JwHD.w5gs!ZS

database: avl-uat 

/* To Create Database & Insert Data */
add-migration InitialCreate 
update-database

In Case of DB Access Issue --> 
Security --> Login --> Builtin\users --> Right Click Properties --> Server Roles --> dbcreators

-----------------------------------------------------------
use ProductsDB;
select * from [dbo].[Categories]
select * from [dbo].[Products]

Call the web API with JavaScript


Microservices Using ASP.NET Core
https://www.c-sharpcorner.com/article/microservice-using-asp-net-core/
Akhil Mittal


Good One 
https://levelup.gitconnected.com/kubernetes-angular-asp-net-core-microservice-architecture-c46fc66ede44


Lazy Loading Using Angular !!!
https://www.c-sharpcorner.com/article/step-by-step-guide-to-implement-lazy-loading-in-an-angular-project/


Entity Framework ABCD: 
https://www.tutorialspoint.com/entity_framework/entity_framework_code_first_approach.htm




