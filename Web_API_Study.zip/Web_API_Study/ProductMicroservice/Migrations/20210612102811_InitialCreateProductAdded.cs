﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ProductMicroservice.Migrations
{
    public partial class InitialCreateProductAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 1,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 12, 15, 58, 2, 644, DateTimeKind.Local).AddTicks(7533), new DateTime(2021, 6, 12, 15, 58, 2, 674, DateTimeKind.Local).AddTicks(6120) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 2,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 12, 15, 58, 2, 674, DateTimeKind.Local).AddTicks(7318), new DateTime(2021, 6, 12, 15, 58, 2, 674, DateTimeKind.Local).AddTicks(7324) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 3,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 12, 15, 58, 2, 674, DateTimeKind.Local).AddTicks(7325), new DateTime(2021, 6, 12, 15, 58, 2, 674, DateTimeKind.Local).AddTicks(7327) });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "CategoryId", "CreatedBy", "CreatedDate", "Description", "ImageUrl", "Name", "Objectversion", "Price", "UpdatedBy", "UpdatedDate" },
                values: new object[,]
                {
                    { 1, 1, "Master Data Input", new DateTime(2021, 6, 12, 15, 58, 2, 676, DateTimeKind.Local).AddTicks(4922), "Electronic Items", "", "Electronics-1", 1, 10, "Master Data Input", new DateTime(2021, 6, 12, 15, 58, 2, 676, DateTimeKind.Local).AddTicks(5408) },
                    { 2, 1, "Master Data Input", new DateTime(2021, 6, 12, 15, 58, 2, 676, DateTimeKind.Local).AddTicks(6217), "Electronic Items", "", "Electronics-2", 1, 10, "Master Data Input", new DateTime(2021, 6, 12, 15, 58, 2, 676, DateTimeKind.Local).AddTicks(6222) },
                    { 3, 1, "Master Data Input", new DateTime(2021, 6, 12, 15, 58, 2, 676, DateTimeKind.Local).AddTicks(6226), "Electronic Items", "", "Electronics-3", 1, 10, "Master Data Input", new DateTime(2021, 6, 12, 15, 58, 2, 676, DateTimeKind.Local).AddTicks(6228) },
                    { 4, 1, "Master Data Input", new DateTime(2021, 6, 12, 15, 58, 2, 676, DateTimeKind.Local).AddTicks(6230), "Electronic Items", "", "Electronics-4", 1, 10, "Master Data Input", new DateTime(2021, 6, 12, 15, 58, 2, 676, DateTimeKind.Local).AddTicks(6232) },
                    { 5, 1, "Master Data Input", new DateTime(2021, 6, 12, 15, 58, 2, 676, DateTimeKind.Local).AddTicks(6234), "Electronic Items", "", "Electronics-5", 1, 10, "Master Data Input", new DateTime(2021, 6, 12, 15, 58, 2, 676, DateTimeKind.Local).AddTicks(6235) }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 5);

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 1,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 12, 0, 14, 22, 510, DateTimeKind.Local).AddTicks(2182), new DateTime(2021, 6, 12, 0, 14, 22, 513, DateTimeKind.Local).AddTicks(1179) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 2,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 12, 0, 14, 22, 513, DateTimeKind.Local).AddTicks(2211), new DateTime(2021, 6, 12, 0, 14, 22, 513, DateTimeKind.Local).AddTicks(2217) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 3,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 12, 0, 14, 22, 513, DateTimeKind.Local).AddTicks(2220), new DateTime(2021, 6, 12, 0, 14, 22, 513, DateTimeKind.Local).AddTicks(2221) });
        }
    }
}
