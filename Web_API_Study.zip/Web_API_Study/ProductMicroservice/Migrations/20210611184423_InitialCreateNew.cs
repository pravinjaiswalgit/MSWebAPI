﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ProductMicroservice.Migrations
{
    public partial class InitialCreateNew : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "Price",
                table: "Products",
                type: "int",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)");

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 1,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 12, 0, 14, 22, 510, DateTimeKind.Local).AddTicks(2182), new DateTime(2021, 6, 12, 0, 14, 22, 513, DateTimeKind.Local).AddTicks(1179) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 2,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 12, 0, 14, 22, 513, DateTimeKind.Local).AddTicks(2211), new DateTime(2021, 6, 12, 0, 14, 22, 513, DateTimeKind.Local).AddTicks(2217) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 3,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 12, 0, 14, 22, 513, DateTimeKind.Local).AddTicks(2220), new DateTime(2021, 6, 12, 0, 14, 22, 513, DateTimeKind.Local).AddTicks(2221) });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "Price",
                table: "Products",
                type: "decimal(18,2)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 1,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 11, 22, 4, 32, 938, DateTimeKind.Local).AddTicks(5804), new DateTime(2021, 6, 11, 22, 4, 32, 953, DateTimeKind.Local).AddTicks(846) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 2,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 11, 22, 4, 32, 953, DateTimeKind.Local).AddTicks(1619), new DateTime(2021, 6, 11, 22, 4, 32, 953, DateTimeKind.Local).AddTicks(1623) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 3,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2021, 6, 11, 22, 4, 32, 953, DateTimeKind.Local).AddTicks(1626), new DateTime(2021, 6, 11, 22, 4, 32, 953, DateTimeKind.Local).AddTicks(1628) });
        }
    }
}
