﻿using Micro.Services.ProductAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Micro.Services.ProductAPI.DbContexts
{
    public class ApplicationDbContext : DbContext
    {
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options)
            
        {


        }
        public DbSet<Product> Products { get; set; }
        protected override  void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Product>().HasData(new Product
            {
                ProductId=3,
                Name="Samosa",
                Price=15,
                Description= "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur",
                ImageUrl="",
                CategoryName="Appetizer"

            });
            modelBuilder.Entity<Product>().HasData(new Product
            {
                ProductId = 4,
                Name = "Paneer Tikka",
                Price=100,
                Description = "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur",
                ImageUrl = "",
                CategoryName = "Main Course"

            });
            modelBuilder.Entity<Product>().HasData(new Product
            {
                ProductId = 5,
                Name = "Fried Rice",
                Price=60,
                Description = "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur",
                ImageUrl = "",
                CategoryName = "Main Course"

            });
        }
    }
}
