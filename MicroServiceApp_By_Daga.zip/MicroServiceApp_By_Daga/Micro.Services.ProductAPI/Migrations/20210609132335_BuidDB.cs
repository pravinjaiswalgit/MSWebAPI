﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Micro.Services.ProductAPI.Migrations
{
    public partial class BuidDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
